from svg_converter.Converter import Converter


def cmd_converter():
    import argparse

    parser = argparse.ArgumentParser(prog="SVG Converter", description="Convert SVG file(s) to PNG or PDF")
    parser.add_argument("svg_files", nargs="+", type=str, help="SVG file(s) to be converted")
    parser.add_argument("--export-type", required=True, choices=["png", "pdf"], type=str, help="Exported file(s) format, PNG or PDF")
    parser.add_argument("--dpi", type=int, help="DPI of the output file", metavar="")
    parser.add_argument("--width", type=int, help="Width of the output file", metavar="")
    parser.add_argument("--height", type=int, help="Height of the output file", metavar="")
    parser.add_argument("--inkscape-exec", type=str, default="inkscape", help="Path to Inkscape if it is not in the PATH", metavar="")
    parser.add_argument("--override", action="store_true", help="Whether to delete the original SVG file")

    args = parser.parse_args()
    svg_files = args.svg_files
    for svg_file in svg_files:
        Converter(svg_file, args.export_type, args.dpi, args.width, args.height, args.inkscape_exec, args.override)
