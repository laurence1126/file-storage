from setuptools import setup, find_packages
from pdf_converter import __version__


setup(
    name="pdf-converter",
    version=__version__,
    description="A Python converter that uses Adobe online tools to convert PDF files into different formats.",
    author="Laurence JIN",
    author_email="laurencejin1126@gmail.com",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "rich >= 13.5.2",
        "pikepdf >= 8.4.1",
        "selenium >= 4.12.0",
        "tabulate >= 0.9.0",
    ],
    entry_points={
        "console_scripts": [
            "pdf-converter=pdf_converter.Converter:invoke_converter",
        ],
    },
)
