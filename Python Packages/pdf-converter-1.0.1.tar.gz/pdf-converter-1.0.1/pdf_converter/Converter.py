import os, shutil, glob, time, re, pikepdf
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from pathlib import Path
from pdf_converter.Logger import Logger
from rich import print
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.progress import Progress, TextColumn, BarColumn, TaskProgressColumn
from tabulate import tabulate


class Converter:
    def __init__(self, pdf_file: str = None) -> None:
        self._pdf_file = pdf_file
        self._download_path = os.path.join(Path.home(), "Downloads")

    def _get_pdf_file(self) -> None:
        if self._pdf_file == None:
            while True:
                pdf_file = input("Enter the path of the PDF file: ")
                pdf_file = re.sub(r"\"|'|& ", "", pdf_file).strip()
                pdf_file = re.sub(r"\\ ", " ", pdf_file)
                if os.path.exists(pdf_file) and os.path.splitext(pdf_file)[1] == ".pdf":
                    self._pdf_file = pdf_file
                    break
                else:
                    print("Invalid input, please try again")
        Logger().info(f"Processing PDF file: {os.path.basename(self._pdf_file)}...")

    def _get_driver(self) -> None:
        options = webdriver.ChromeOptions()
        options.add_argument("--log-level=3")
        options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")
        options.add_argument(
            "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36"
        )
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        Logger().info("Getting headless Chrome driver...")
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 600)

    def crack_pdf(self) -> None:
        self._get_pdf_file()
        try:
            # No password scenario
            f = pikepdf.open(self._pdf_file, allow_overwriting_input=True)
            os.remove(self._pdf_file)
            f.save(self._pdf_file)
            Logger().info("PDF file protection cracked")
            return
        except pikepdf._core.PasswordError:
            # Allow wrong password for at most 5 times
            count = 0
            while count <= 5:
                if count > 0:
                    Logger().warning(f"Invalid password, please try again ({count}/5)")
                count += 1
                password = input("This PDF file is password protected, please enter the password: ")
                try:
                    f = pikepdf.open(self._pdf_file, allow_overwriting_input=True, password=password)
                    os.remove(self._pdf_file)
                    f.save(self._pdf_file)
                    Logger().info("PDF file protection cracked")
                    return
                except pikepdf._core.PasswordError:
                    pass
            raise RuntimeError(f"{os.path.basename(self._pdf_file)}: Invalid password, maximum attempts reached")

    def _upload_and_convert(self):
        # Upload
        Logger().info("Waiting for PDF file to upload...")
        time.sleep(3)
        file_input = self.driver.find_element(By.ID, "fileInput")
        file_input.send_keys(self._pdf_file)

        # Convert
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(complete_style="red bold", finished_style="green bold"),
            TaskProgressColumn("[blue bold]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task("[red bold]{:^13}".format("Uploading..."), total=100)
            percentage_xpath = "//div[contains(@class, 'spectrum-BarLoader-percentage')]"
            self.wait.until(lambda _: self.driver.find_element(By.XPATH, percentage_xpath).is_displayed())
            while True:
                if self.driver.find_elements(By.XPATH, "//span[text()='Converting...']"):
                    progress.update(task, description="[red bold]{:^13}".format("Converting..."))
                try:
                    progress.update(task, completed=int(self.driver.find_element(By.XPATH, percentage_xpath).text.replace("%", "")))
                    time.sleep(0.1)
                except:
                    progress.update(task, completed=100, description="[green bold]{:^13}".format("Completed"))
                    break

    def _encrypt(self):
        # Upload
        Logger().info("Waiting for PDF file to upload...")
        time.sleep(3)
        file_input = self.driver.find_element(By.ID, "fileInput")
        file_input.send_keys(self._pdf_file)

        # Input password
        while True:
            password = input("Input password: ")
            if len(password) >= 6:
                break
            else:
                print("Invalid password, password length needs to be greater than 6.")
        self.wait.until(lambda _: self.driver.find_element(By.XPATH, "//input[@id='password-id']").is_enabled())
        self.driver.find_element(By.XPATH, "//input[@id='password-id']").send_keys(password + "\n")
        self.driver.find_element(By.XPATH, "//input[@id='repassword-id']").send_keys(password + "\n")

        # Convert
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(complete_style="red bold", finished_style="green bold"),
            TaskProgressColumn("[blue bold]{task.percentage:>3.0f}%"),
        ) as progress:
            task = progress.add_task("[red bold]{:^13}".format("Encrypting..."), total=100)
            percentage_xpath = "//div[contains(@class, 'spectrum-BarLoader-percentage')]"
            self.wait.until(lambda _: self.driver.find_element(By.XPATH, percentage_xpath).is_displayed())
            while True:
                try:
                    progress.update(task, completed=int(self.driver.find_element(By.XPATH, percentage_xpath).text.replace("%", "")))
                    time.sleep(0.1)
                except:
                    progress.update(task, completed=100, description="[green bold]{:^13}".format("Completed"))
                    break

    def _download_file(self):
        Logger().info("Waiting for PDF file to download...")
        self.wait.until(lambda _: self.driver.find_element(By.XPATH, "//button[text()='Download']").is_displayed())
        download = self.driver.find_element(By.XPATH, "//button[text()='Download']")
        download.click()
        time.sleep(3)

        loop = True
        while loop:
            loop = False
            time.sleep(1)
            for fname in os.listdir(self._download_path):
                if fname.endswith(".crdownload"):
                    loop = True
                    break

    def _move_file(self, extension: str, check_override: bool = False) -> None:
        base_name = os.path.basename(self._pdf_file)
        folder_path = os.path.dirname(self._pdf_file)
        latest = max(glob.glob(os.path.join(self._download_path, os.path.splitext(base_name)[0]) + f"*.{extension}"), key=os.path.getctime)
        destination = latest.replace(self._download_path, folder_path)

        if check_override:
            override = Confirm.ask("Do you want to override the original file?", default=False)
        else:
            override = False

        if override:
            os.remove(self._pdf_file)
            destination = self._pdf_file
            shutil.move(latest, destination)
            Logger().info("Original PDF is now password encrypted")
        elif os.path.dirname(destination).lower() != self._download_path.lower():
            if os.path.exists(destination):
                override = Confirm.ask("Same name file already existed, do you want to override?", default=True)
                if override:
                    os.remove(destination)
                    shutil.move(latest, destination)
                    Logger().info("New file moved to the same directory")
                else:
                    Logger().info("New file not moved, it is located in the Downloads folder")
            else:
                shutil.move(latest, destination)
                Logger().info("New file moved to the same directory")
        else:
            Logger().info("New file not moved, it is located in the Downloads folder")

    def close_driver(self) -> None:
        try:
            self.driver.close()
        except:
            pass

    def pdf2xlsx(self) -> None:
        self.crack_pdf()
        self._get_driver()
        self.driver.get("https://www.adobe.com/hk_en/acrobat/online/pdf-to-excel.html")
        self._upload_and_convert()
        self._download_file()
        self.driver.close()
        Logger().info("PDF file converted to xlsx")
        self._move_file("xlsx")

    def pdf2docx(self) -> None:
        self.crack_pdf()
        self._get_driver()
        self.driver.get("https://www.adobe.com/hk_en/acrobat/online/pdf-to-word.html")
        self._upload_and_convert()
        self._download_file()
        self.driver.close()
        Logger().info("PDF file converted to docx")
        self._move_file("docx")

    def pdf2ppt(self) -> None:
        self.crack_pdf()
        self._get_driver()
        self.driver.get("https://www.adobe.com/hk_en/acrobat/online/pdf-to-ppt.html")
        self._upload_and_convert()
        self._download_file()
        self.driver.close()
        Logger().info("PDF file converted to pptx")
        self._move_file("pptx")

    def pdf_encrypt(self) -> None:
        self.crack_pdf()
        self._get_driver()
        self.driver.get("https://www.adobe.com/hk_en/acrobat/online/password-protect-pdf.html")
        self._encrypt()
        self._download_file()
        self.driver.close()
        Logger().info("PDF file encrypted")
        self._move_file("pdf", True)


def fix_width_tabulate(table: str, width: int = 0) -> str:
    table = table.split("\n")
    format_string = f"^{width}"
    for i in range(len(table)):
        table[i] = f"{table[i]: {format_string}}"
    return "\n".join(table)


def invoke_converter():
    console = Console()
    option_table = tabulate(
        [
            [1, "PDF to Excel"],
            [2, "PDF to Word"],
            [3, "PDF to PowerPoint"],
            [4, "Encrypt PDF"],
            [5, "Crack PDF protection"],
            [6, "Exit program"],
        ],
        tablefmt="fancy_outline",
    )
    while True:
        try:
            console.print("\nWelcome to the [green bold]PDF Online Converter Tool[/green bold] (Adobe)", justify="center")
            console.print(fix_width_tabulate(option_table), justify="center")  # Fix width at 46 if not justified
            option = Prompt.ask("Which service do you want", choices=["1", "2", "3", "4", "5", "6"], show_choices=False)
            converter = Converter()
            match option:
                case "1":
                    converter.pdf2xlsx()
                case "2":
                    converter.pdf2docx()
                case "3":
                    converter.pdf2ppt()
                case "4":
                    converter.pdf_encrypt()
                case "5":
                    converter.crack_pdf()
                case _:
                    break
        except:
            converter.close_driver()
            console.print_exception()
            input("Press Enter to continue the program...")


if __name__ == "__main__":
    invoke_converter()
