import subprocess, os
from typing import Literal
from svg_converter.Logger import Logger
from PIL import Image


class Converter:
    def __init__(
        self,
        svg_file: str,
        export_type: Literal["png", "pdf"],
        dpi: int = None,
        width: int = None,
        height: int = None,
        inkscape_exec: str = "inkscape",
        override: bool = False,
        squared: bool = False,
    ) -> None:
        if os.path.splitext(svg_file)[1] != ".svg" or not os.path.exists(svg_file):
            raise ValueError("Invalid input. Please enter an existing SVG file.")
        else:
            self._svg_file = svg_file
        if export_type not in ["png", "pdf"]:
            raise ValueError("Invalid input. Please enter either 'png' or 'pdf' as export_type.")
        else:
            self._export_type = export_type
        self._dpi = dpi
        self._width = width
        self._height = height
        self._inkscape_exec = inkscape_exec
        self.convert()
        if override:
            os.remove(self._svg_file)
        if squared:
            self.make_squared()

    def convert(self) -> None:
        Logger().info(f"Start converting SVG file ({os.path.basename(self._svg_file)})...")
        base_name = os.path.splitext(self._svg_file)[0]
        command = [self._inkscape_exec, self._svg_file, f"--export-type={self._export_type}", f"--export-filename={base_name}.{self._export_type}"]

        if self._dpi != None:
            command += [f"--export-dpi={self._dpi}"]
        if self._width != None:
            command += [f"--export-width={self._width}"]
        if self._height != None:
            command += [f"--export-height={self._height}"]

        run = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        if run.returncode == 0:
            Logger().info(f"SVG file converted to {self._export_type.upper()} successfully.")
        else:
            Logger().error("Conversion failed.")

    def make_squared(self) -> None:
        if self._export_type == "png":
            img = Image.open(f"{os.path.splitext(self._svg_file)[0]}.png")
            width, height = img.size
            if width != height:
                size = (width, width) if width > height else (height, height)
                new_img = Image.new("RGBA", size, (255, 255, 255, 0))
                new_img.paste(img, ((size[0] - width) // 2, (size[1] - height) // 2))
                new_img.save(f"{os.path.splitext(self._svg_file)[0]}.png")
                Logger().info("Image squared successfully.")
            else:
                Logger().info("Image is already squared.")
        else:
            Logger().error("Squared function is only available for PNG images.")
