import subprocess, os
from typing import Literal
from svg_converter.Logger import Logger
from PIL import Image


class Converter:
    def __init__(
        self,
        svg_file: str,
        export_type: Literal["png", "pdf"],
        dpi: int = None,
        width: int = None,
        height: int = None,
        inkscape_exec: str = "inkscape",
        override: bool = False,
        squared: bool = False,
        color: str = None,
    ) -> None:
        if os.path.splitext(svg_file)[1] != ".svg" or not os.path.exists(svg_file):
            raise ValueError("Invalid input. Please enter an existing SVG file.")
        else:
            self._svg_file = svg_file
        if export_type not in ["png", "pdf"]:
            raise ValueError("Invalid input. Please enter either 'png' or 'pdf' as export_type.")
        else:
            self._export_type = export_type
        self._dpi = dpi
        self._width = width
        self._height = height
        self._inkscape_exec = inkscape_exec
        self._color = color
        self._adjusted_svg = None
        if self._color:
            self._adjusted_svg = self.adjust_color()
        self.convert()
        if self._adjusted_svg:
            os.remove(self._adjusted_svg)
        if override:
            os.remove(self._svg_file)
        if squared:
            self.make_squared()

    def convert(self) -> None:
        if self._adjusted_svg:
            original_svg = self._svg_file
            self._svg_file = self._adjusted_svg
        Logger().info(f"Start converting SVG file ({os.path.basename(self._svg_file)})...")
        base_name = os.path.splitext(self._svg_file)[0].replace("_tmp", "")
        command = [self._inkscape_exec, self._svg_file, f"--export-type={self._export_type}", f"--export-filename={base_name}.{self._export_type}"]

        if self._dpi != None:
            command += [f"--export-dpi={self._dpi}"]
        if self._width != None:
            command += [f"--export-width={self._width}"]
        if self._height != None:
            command += [f"--export-height={self._height}"]

        run = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        if run.returncode == 0:
            Logger().info(f"SVG file converted to {self._export_type.upper()} successfully.")
        else:
            Logger().error("Conversion failed.")
        if self._adjusted_svg:
            self._svg_file = original_svg

    def make_squared(self) -> None:
        if self._export_type == "png":
            img = Image.open(f"{os.path.splitext(self._svg_file)[0]}.png")
            width, height = img.size
            if width != height:
                size = (width, width) if width > height else (height, height)
                new_img = Image.new("RGBA", size, (255, 255, 255, 0))
                new_img.paste(img, ((size[0] - width) // 2, (size[1] - height) // 2))
                new_img.save(f"{os.path.splitext(self._svg_file)[0]}.png")
                Logger().info("Image squared successfully.")
            else:
                Logger().info("Image is already squared.")
        else:
            Logger().error("Squared function is only available for PNG images.")

    def adjust_color(self) -> str:
        with open(self._svg_file, "r") as svg_file:
            svg = svg_file.read()
            index = svg.find("<path ")
            new_svg = svg[:index] + f'<path fill="{self._color}" ' + svg[index + 6 :]

            base_name = os.path.splitext(self._svg_file)[0]
            adjusted_svg_path = base_name + "_tmp" + ".svg"
            with open(adjusted_svg_path, "w") as new_svg_file:
                new_svg_file.write(new_svg)
            return adjusted_svg_path
