from setuptools import setup, find_packages
from svg_converter import __version__


setup(
    name="svg-converter",
    version=__version__,
    description="A Python converter that uses Inkscape to convert files from SVG to PNG or PDF",
    author="Laurence JIN",
    author_email="laurencejin1126@gmail.com",
    packages=find_packages(),
    install_requires=[
        "rich",
    ],
    entry_points={
        "console_scripts": [
            "svg-converter=svg_converter.Cmd:cmd_converter",
        ],
    },
)
