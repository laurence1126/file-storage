import logging
from rich.logging import RichHandler


class Logger(logging.Logger):
    def __init__(self):
        super().__init__(name="Rich Logger")
        self.setLevel(logging.INFO)
        date_fmt = "[%Y-%m-%d %H:%M:%S]"
        rich_fmt = "{message}"
        style = "{"
        if not self.hasHandlers():
            # Config Rich handler
            rich_handler = RichHandler(rich_tracebacks=True, show_path=True)
            rich_formatter = logging.Formatter(fmt=rich_fmt, datefmt=date_fmt, style=style)
            rich_handler.setFormatter(rich_formatter)
            self.addHandler(rich_handler)
