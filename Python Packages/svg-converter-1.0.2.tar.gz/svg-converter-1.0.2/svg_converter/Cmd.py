import argparse
from svg_converter.Converter import Converter


class SingleMetavarHelpFormatter(argparse.HelpFormatter):
    def _format_action_invocation(self, action):
        if not action.option_strings:
            default = self._get_default_metavar_for_positional(action)
            (metavar,) = self._metavar_formatter(action, default)(1)
            return metavar
        else:
            parts = []
            if action.nargs == 0:
                parts.extend(action.option_strings)
            else:
                default = self._get_default_metavar_for_optional(action)
                args_string = self._format_args(action, default)
                parts.extend(action.option_strings)
                parts[-1] += " %s" % args_string
            return ", ".join(parts)


def cmd_converter():
    parser = argparse.ArgumentParser(
        prog="SVG Converter", description="Convert SVG file(s) to PNG or PDF", formatter_class=SingleMetavarHelpFormatter
    )
    parser.add_argument("svg_files", nargs="+", type=str, help="SVG file(s) to be converted")
    parser.add_argument("-t", "--export-type", default="pdf", type=str, help="exported file(s) format, PNG or PDF (default: pdf)", metavar="")
    parser.add_argument("-D", "--dpi", type=int, help="DPI of the output file(s)", metavar="")
    parser.add_argument("-W", "--width", type=int, help="width of the output file(s)", metavar="")
    parser.add_argument("-H", "--height", type=int, help="height of the output file(s)", metavar="")
    parser.add_argument("--inkscape-exec", default="inkscape", type=str, help="path to Inkscape executable if it is not in the PATH", metavar="")
    parser.add_argument("-O", "--override", action="store_true", help="whether to delete the original SVG file(s)")

    args = parser.parse_args()
    svg_files = args.svg_files
    for svg_file in svg_files:
        Converter(svg_file, args.export_type, args.dpi, args.width, args.height, args.inkscape_exec, args.override)
